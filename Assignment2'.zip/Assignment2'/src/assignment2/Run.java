/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import javax.swing.JFrame;

/**
 *
 * @author Mohamed
 */
public class Run extends JFrame {
    
     public static void main(String[] args) {
        
        Controller controller= new Controller();
         Frame1 frame= new Frame1(controller);
        controller.addDept("CS", "Computer Science");
        controller.addDept("IT", "Information Technology");
       frame.setVisible(true);
       frame.pack();
   
    }
    
    
}
