/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.util.ArrayList;

/**
 *
 * @author Abdiaziz
 */
public class Department  {
    
    private String ID;
    private String Name;
    private ArrayList<Course> courses;
    
   
    public String getName(){
        
        return Name;
    }
    
    public Department(String ID, String Name){
        
        this.ID=ID;
        this.Name=Name;
    }
    public String getDepID(){
        
        return this.ID;
    }
    public void setName(String Name){
        
        this.Name= Name;
    }
    
    public void setID( String ID){
        
        this.ID=ID;
        
    }
 
    public ArrayList<Course> getDeptCourse(){
        
        return courses;
    }
    
    public void PrintCourse()
    {
        
        for(Course s: courses){
            
           s.info();
        }
    }
    
     public boolean matches(String dep_ID) {
        
        return this.ID.equals(dep_ID.trim()); //To change body of generated methods, choose Tools | Templates.
    }
     
     public void addDeptCourse(Course newCourse){
         
         this.courses.add(newCourse);
     }
     
     public void deleteCourse ( Course deletedCourse){
         
         for(Course c: courses){
             
             if(c.getID().matches(deletedCourse.getID())){
                 
                this.courses.remove(c);
                 
                 
             }
         }
         
      
     }
     
}
