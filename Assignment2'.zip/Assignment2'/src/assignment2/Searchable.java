/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

/**
 *
 * @author Mohamed
 */
public interface Searchable {
    
   
    public boolean contains(String key);
    public String info();

    public void setCourse(String ID, String title, int credits, Department dep_ID);
   //
    
    
    
}
