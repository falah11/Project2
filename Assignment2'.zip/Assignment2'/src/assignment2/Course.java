/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import static java.sql.DriverManager.println;
import static java.time.Clock.system;

/**
 *
 * @author Mohamed
 */
public class Course implements Searchable {
    
    private String ID;
    private String title;
    private int credits;
    private Department dep_ID;
    
    
    public Course(String ID, String title,int credits, Department dep_ID){
        
        this.ID=ID;
        this.title=title;
        this.credits=credits;
        this.dep_ID=dep_ID;
    }
    
   public String getID()
   {
       return  this.ID;
   }
    
    public void setCredits( int cre)throws Exception{
        
        if(!(cre> 0&& cre <6)){
            
            throw new Exception("Invalid Entry 1-5");
        }
        else{
            this.credits=cre;
            
        }
    }
    @Override
   public void setCourse(String ID, String title,int credits,Department dep_ID){
        this.ID=ID;
        this.title=title;
        if(!(credits> 0&& credits <6)){
            
            System.out.println("Invalid Entry 1-5");
        }
        else{
            this.credits=credits;
            
        }
        
        this.dep_ID=dep_ID;
    }
    @Override
    
    public boolean contains(String key){
        return ID.contains(key);
        
    }
    @Override
    
    public String info(){
        
        return ID   + title ;
    }
    
     public boolean matches(String ID)
     {
         return this.ID.equals(ID);
         
     }
    
}
