/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment2;

import java.util.ArrayList;

/**
 *
 * @author Mohamed
 */
public class Controller {
    
    private ArrayList<Course> courses = new ArrayList();
    private ArrayList<Department> dept= new ArrayList();
    
    public void addCourse(String ID, String title,String credits,String dep_ID){
     int   cred = Integer.parseInt(credits);
        Department d= FindDept(ID);
        Course c = new Course(ID,title,cred,d);
        courses.add(c);
        }
    
    public Department FindDept(String ID){
        
        for(Department d:dept)
            
            if(d.getDepID().equals(ID))
                return d;
        return null;
    }
    
    public ArrayList<String> getDeptID(){
        
        ArrayList<String> res = new ArrayList<String>();
        
        for(Department d: dept){
            
            res.add(d.getDepID());
        }
        return res;
    }
    
    public ArrayList<String> getCourseinfo(){
        
        ArrayList<String> res = new ArrayList<String>();
        
        for(Course c: courses){
            
            res.add(c.info());
        }
        return res;
    }
  
    public void editCourse(String ID, String title,int credits,String dep_ID){
        
         for(Course c:courses){
            
            Department d = FindDept(dep_ID);
                
               c.setCourse( ID,  title, credits, d);
               
            }
         }    
    
    //public void DisplayCourse(String ID){
      //  for(Course c:courses){
        //     if(c.contains(ID)){
          //       c.info();
                 
            // }
            
        //}
        
   // }
    public void addDept(String ID, String name){

        Department department = new Department(ID,name);
        dept.add(department);
    }

        

    }
    
   

   

