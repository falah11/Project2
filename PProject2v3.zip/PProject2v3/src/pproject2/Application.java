/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pproject2;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Mohamed
 */
public class Application {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Controller controller=Controller.instance();

        SimpleDateFormat formatter= new SimpleDateFormat("M-d-yyyy");
        Calendar today = Calendar.getInstance();
        today.set(2016, Calendar.JANUARY, 04);
        
        controller.addActor("Actor_1", "Mike Myers", Actor.Gender.M);
        controller.addActor("Actor_2", "Eddie Murphy", Actor.Gender.M);
        controller.addActor("Actor_3", "Suraj Sharma", Actor.Gender.M);
        controller.addActor("Actor_4", "Kristen Bell", Actor.Gender.F);
        controller.addActor("Actor_5", "Idina Menzel", Actor.Gender.F);
        controller.addActor("Actor_6", "Billy Crystal", Actor.Gender.M);
        controller.addActor("Actor_7", "John Goodman", Actor.Gender.M);
        controller.addActor("Actor_8", "mary Gibbs", Actor.Gender.F);
        
        controller.addMovie("Shrek_1", Movie.Rating.PG, "Comedy", 2001, "Shrek", Movie.Language.English, "DVD_1_1", controller.findActor("Actor_1"), "funny");
        Movie tempMovie = controller.findMovie("Shrek_1");
        Actor tempActor = controller.findActor("Actor_2");
        tempMovie.addActor(tempActor);
        
        controller.addMovie("Monsters_1", Movie.Rating.G, "Comedy", 2001, "Monsters Inc", Movie.Language.English, "DVD_4_1", controller.findActor("Actor_6"), "funny");
        tempMovie = controller.findMovie("Monsters_1");
        tempActor = controller.findActor("Actor_7");
        tempMovie.addActor(tempActor);
        tempActor = controller.findActor("Actor_8");
        tempMovie.addActor(tempActor);
        
        controller.addMovie("Pi_1", Movie.Rating.PG, "Drama", 2012, "Life of Pi", Movie.Language.French, "DVD_2_1", controller.findActor("Actor_3"), "thrilling");
        
        controller.addMovie("Frozen_1", Movie.Rating.PG, "Musical", 2013, "Frozen", Movie.Language.English, "DVD_3_1", controller.findActor("Actor_4"), "family friendly");
        tempMovie = controller.findMovie("Frozen_1");
        tempActor = controller.findActor("Actor_5");
        tempMovie.addActor(tempActor);
        tempMovie.addDVD("DVD_3_2");
        tempMovie.addDVD("DVD_3_3");
        tempMovie.addDVD("DVD_3_4");
        tempMovie.addDVD("DVD_3_5");
        tempMovie.addDVD("DVD_3_6");
        tempMovie.addDVD("DVD_3_7");
        tempMovie.addDVD("DVD_3_8");
        tempMovie.addDVD("DVD_3_9");
        tempMovie.addDVD("DVD_3_10");
        tempMovie.findDVD("DVD_3_8").setLost(true);
        
        controller.addCustomer("bob@gmail.com", "112 1st Street", "816-123-1234", "password", "Bob Smith");
        controller.addCustomer("francois@gmail.com", "10 French Avenue", "423-123-1234", "12345", "Francois Hollande");
        controller.addCustomer("alice@frozenfanclub.com", "725 West 50th Terrace", "816-376-9366", "ilovefrozen", "Alice Bell");
        
        
        Customer tempCust = controller.findCustomer("bob@gmail.com");
        Payment tempPay = new Payment(7.50, Payment.PaymentMethod.CASH);
        controller.rentMovie(tempCust, Controller.SearchType.YEAR, "2001", "Shrek_1", "DVD_1_1", tempPay, "Bob_Shrek_1", 
                today, Rental.RentMethod.GOTOSHOP, Rental.ReturnMethod.DROPPING, Request.ReqType.GOTO_SHOP);
        
        today.set(2016, Calendar.FEBRUARY, 4);
        controller.rentMovie(tempCust, Controller.SearchType.YEAR, "2013", "Frozen_1", "DVD_3_1", tempPay, "Bob_Frozen_1", 
                today, Rental.RentMethod.GOTOSHOP, Rental.ReturnMethod.DROPPING, Request.ReqType.GOTO_SHOP);
        
        
        today.set(2016, Calendar.FEBRUARY, 10);
        tempCust = controller.findCustomer("alice@frozenfanclub.com");
        tempPay = new Payment(10.00, Payment.PaymentMethod.CREDIT);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_1", tempPay, "Alice_Frozen_1", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_2", tempPay, "Alice_Frozen_1", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.NAME, "Frozen", "Frozen_1", "DVD_3_3", tempPay, "Alice_Frozen_2", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.GENRE, "Musical", "Frozen_1", "DVD_3_4", tempPay, "Alice_Frozen_3", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.RATING, "PG", "Frozen_1", "DVD_3_5", tempPay, "Alice_Frozen_4", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.ACTOR, "Kristen", "Frozen_1", "DVD_3_6", tempPay, "Alice_Frozen_5", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.ACTOR, "Idina", "Frozen_1", "DVD_3_7", tempPay, "Alice_Frozen_6", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_7", tempPay, "Alice_Frozen_7", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_8", tempPay, "Alice_Frozen_7", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_9", tempPay, "Alice_Frozen_7", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_10", tempPay, "Alice_Frozen_8", 
                today, Rental.RentMethod.BYMAIL, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        
        //***** Return Bob's Frozen rental *****//
        
        
        today.set(2016, Calendar.FEBRUARY, 11);
        tempCust = controller.findCustomer("francois@gmail.com");
        tempPay = new Payment(8.00, Payment.PaymentMethod.CREDIT);
        controller.rentMovie(tempCust, Controller.SearchType.LANGUAGE, "FRENCH", "Pi_1", "DVD_4_1", tempPay, "Francois_Pi_1", 
                today, Rental.RentMethod.GOTOSHOP, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        controller.rentMovie(tempCust, Controller.SearchType.KEY, "family", "Frozen_1", "DVD_3_2", tempPay, "Francois_Frozen_1", 
                today, Rental.RentMethod.GOTOSHOP, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        tempPay = new Payment(6.00, Payment.PaymentMethod.CREDIT);
        controller.rentMovie(tempCust, Controller.SearchType.YEAR, "2001", "Monsters_1", "DVD_4_1", tempPay, "Francois_Monsters_1", 
                today, Rental.RentMethod.GOTOSHOP, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
        
        //***** Return Bob's Shrek rental *****//
        
        
        tempPay = new Payment(8.00, Payment.PaymentMethod.CREDIT);
        controller.rentMovie(tempCust, Controller.SearchType.YEAR, "2001", "Shrek_1", "DVD_1_1", tempPay, "Bob_Shrek_1", 
                today, Rental.RentMethod.GOTOSHOP, Rental.ReturnMethod.SHIPPING, Request.ReqType.BY_MAIL);
    }
}
