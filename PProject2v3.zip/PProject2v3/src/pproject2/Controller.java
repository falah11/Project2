/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pproject2;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import pproject2.Movie.Language;
import pproject2.Movie.Rating;
import pproject2.Rental.ReturnMethod;
import pproject2.Rental.Status;

/**
 *
 * @author Mohamed, Adam
 */
public class Controller {
    
    private static Controller singleton;
    
    private HashMap<String, Movie> movies= new HashMap<String,Movie>();
    private HashMap<String, Customer> customers= new HashMap<String,Customer>();
    private HashMap<String, Rental> rentals= new HashMap<String,Rental>();
    private HashMap<String, Request> requests= new HashMap<String,Request>();
    private HashMap<String, Actor> actors= new HashMap<String,Actor>();
    
    public static final double RENT_COST = 7.50;
    public static final int NUM_DAYS_IN_WEEK = 7;
    public static final int RETURN_SOON_LIMIT = 2;
    public static final int MAX_NUM_DVDS = 10;
    public static final SimpleDateFormat formatter= new SimpleDateFormat("M-d-yyyy");
    
    public static final Movie NO_MOVIE = new Movie("nothing");
    public static final Actor NO_ACTOR = new Actor("nothing", "nothing", Actor.Gender.M);
    public static final Customer NO_CUSTOMER = new Customer("nothing");
    public static final Rental NO_RENTAL = new Rental("nothing");
    
    
    public enum SearchType{
        KEY, NAME, YEAR, GENRE, RATING, LANGUAGE, ACTOR
    }
    
    
    private Controller(int i) {}
    
    public static Controller instance(){
        if(singleton==null){
            singleton= new Controller(0);
        }
        return singleton;
    }
    
    protected Controller() throws Exception {
        if(getClass().getName().equals("Controller")){
            throw new Exception();
        }
    }
    
    // be able to keep track of Movies and Customers and rental and request as well
    
    public Movie addMovie(String id){
       Movie movie= new Movie(id);
       movies.put(id, movie);
       return movie;
    }
    
    public Movie addMovie(String id,Rating rate, String gen, int year, String name, Language lang, String dvdSN, Actor actor, String kywd){
       Movie movie= new Movie(id, rate, gen, year, name, lang, dvdSN, actor, kywd);
       movies.put(id, movie);
       return movie;
    }
    
    public Actor addActor(String actID , String name, Actor.Gender gend){
        Actor actor = new Actor(actID, name, gend);
        return actor;
    }
    
    public Customer addCustomer(String email, String address ,String phone, String pass, String name){
        Customer cust= new Customer(email, address, phone, pass, name);
        customers.put(email, cust);
        return cust;
    }
    
    
    public Movie findMovie(String ID){
        for(Entry<String,Movie> entry: movies.entrySet()){
            if(entry.getKey().contains(ID)){
                return entry.getValue();
            }
        }
        return NO_MOVIE;
    }
    
    public Customer findCustomer(String email){
        for(Entry<String,Customer> entry: customers.entrySet()){
            if(entry.getKey().contains(email)){
                return entry.getValue();
            }
        }
        return NO_CUSTOMER;
    }
    
    public Actor findActor(String ID){
        for(Entry<String,Actor> entry: actors.entrySet()){
            if(entry.getKey().contains(ID)){
              return entry.getValue();
            }
        }
        return NO_ACTOR;
    }
    
    public Rental findRental(String ID){
        for(Entry<String,Rental> entry: rentals.entrySet()){
            if(entry.getKey().contains(ID)){
              return entry.getValue();
            }
        }
        return NO_RENTAL;
    }
    
    public void addRental(String rentID, Calendar rtDate, DVD dvd, Customer cust, 
                        Rental.RentMethod rentMethod, Rental.ReturnMethod rtrnMethod, String movID)
    {
        Movie movie= findMovie(movID);
        Customer customer= findCustomer(cust.getEmail());
        if(movie!=NO_MOVIE && customer!=NO_CUSTOMER){
            Calendar returnDate = (Calendar)rtDate.clone();
            returnDate.add(Calendar.DAY_OF_MONTH, NUM_DAYS_IN_WEEK);
            Rental rent = new Rental(rentID, rtDate, returnDate, dvd, cust, rentMethod, rtrnMethod, movID);
            rentals.put(rentID, rent);
        }
    }
    
    public void removeDVD(String rentID){
        for(Entry<String,Rental> entry:rentals.entrySet()){
            if(entry.getKey().equals(rentID)){
                rentals.remove(rentID);
            }
        }
    }
    
    public void addRequest(Calendar reqDate,String movID,Customer cust){
        Request req = new Request(reqDate,movID,cust);
        Movie movie= findMovie(movID);
        //Customer customer= findCustomer(cust.getEmail());
        if(movie!=NO_MOVIE){
            requests.put(movID, req);
        }
    }
    
    public void removeRequest(String movID){
        for(Entry<String,Request> entry:requests.entrySet()){
            if(entry.getKey().equals(movID)){
                requests.remove(movID);
            }
        }
    }
    
    /*      First decides on the type of search the user is using, then creates 
        a for loop seraching the movie list for movies matching the search type.
            We could save several lines by placing the switch statement inside a
        for loop, but that would mean checking the search type each time, despite
        the fact that the search type does not change.
            We could make a different search method for each search type, but
        keeping the movie search to one method seems better than spreading it out
        to several.
    */
    public List<Movie> movieSearch(SearchType type, String search){
        List<Movie> movieList = new ArrayList<Movie>();
        switch (type){
            case KEY:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().findKeyword(search).toString().contains(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
            case NAME:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().getName().contains(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
            case YEAR:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().getYear() == Integer.parseInt(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
            case GENRE:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().getGenre().contains(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
            case RATING:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().getRating().toString().contains(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
            case LANGUAGE:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().getLanguage().toString().contains(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
            case ACTOR:
                for(Entry<String,Movie> entry: movies.entrySet()){
                    if(entry.getValue().findActor(search).getActorName().contains(search)){
                        movieList.add(entry.getValue());
                    }
                }
                break;
        }
        return movieList;
    }
    
    /*      The rental requests are hardcoded. If they were interactive, we would
        only have the Customer parameter, then ask the user to input the other
        parameters when necessary (via an input stream). 
            For instance, we could add an input for movie search type and the
        string to be searched right before the first line, which searches for the
        movies.
            It should be unnecessary to have parameters for both Rental and Request
        when each call of rentMovie only produces one, but when hard-coding
        the inputs, we need to provide both.
    */
    public void rentMovie(Customer cust, SearchType type, String search, String movID, String dvdID,
                        Payment pay, String rentID, Calendar date, Rental.RentMethod rentMethod, 
                        Rental.ReturnMethod rtrnMethod, Request.ReqType reqType)
    {
        List<Movie> moviesSearched = movieSearch(type, search);
        for (int i = 0; i < moviesSearched.size(); i++){
            System.out.println(moviesSearched.get(i).INFO() + "\n");
        }
        /* Ask for the movie ID the customer wants.  Normally would place input here.
            Would inform customer that choosing an available movie means renting
            and choosing an unavailable (yet existing) movie means requesting. */
        Movie movieChoice = findMovie(movID);
        
        if(movieChoice==NO_MOVIE){ //***** Customer input an invalid ID. *****//
            System.out.println("No movie found.\n");
            // Go to end of rentMovie method.
            
        } else if(movieChoice.checkAvailability()){ //***** Movie is available, so rent. *****//
            //Choose a dvd for the movie.
            movieChoice.listAvailableDVDs();
            DVD dvdChoice = movieChoice.findDVD(dvdID);
            
            /* The project description describes making a rental and then cancelling it
                should the customer be unable to pay, but it makes more sense to
                instead check if the customer can pay and THEN make the rental. */
            if (pay.getAmount() < RENT_COST){
                System.out.println("Insufficient funds, rental cancelled.\n");
            } else if (dvdChoice.getPos()==DVD.Position.RENTED || dvdChoice.isLost())
                 //The customer shouldn't be able to see this.  But they will anyway.
                System.out.println("That dvd is unavailable.\n");
            else {
                addRental(rentID, date, dvdChoice, cust, rentMethod, rtrnMethod, movieChoice.getID());
                System.out.println("You have rented " + movieChoice.getName() + ".\n");
            }
            // Go to end of rentMovie method.
            
        } else { //***** Movie exists but is unavailable, so request. *****//
            /* Don't always want to make the request.  Decline the request if there
                are over TEN dvds for a single movie, or if one rental for the movie
                is due within 2 days. */
            if (movieChoice.numDVDs() >= MAX_NUM_DVDS){
                System.out.println("Sorry, we cannot fulfill that request.\n");
                // Go to end of rentMovie method;
                
            } else {
            //Check the list of rentals for this movie
                Calendar returnSoon = (Calendar)date.clone();
                returnSoon.add(Calendar.DAY_OF_MONTH, RETURN_SOON_LIMIT);
                for(Entry<String,Rental> entry: rentals.entrySet()){
                    if(entry.getValue().getMovieID().equals(movID)){ //Rental is for movie we want
                        if(entry.getValue().getReturnDate().compareTo(returnSoon) <= 0){ //Someone will return a movie within TWO days
                            System.out.println("We apologize, but someone is returning a movie soon."
                                    + "\n If you could wait two days, a version of the movie should be available then.\n"); //mentions TWO days
                            return;
                            // Break out of rentMovie method.
                        }
                    }
                }
                /* No one with a rental of this movie is returning it soon, and
                    there are less than 10 dvds of the movie, so we can make a request. */
                addRequest(date, movID, cust);
                System.out.println("Request has been filed, we will return to you when your dvd is ready.\n");
                // Go to end of rentMovie method, as you can see.
            }
        }
    }
}


    
