/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pproject2;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Mohamed, Adam
 */
public class Rental implements Searchable {
    
    private String rentID;
    private Calendar rentDate;
    private Calendar returnDate;
    private Status status;
    private DVD dvd;
    private Customer customer;
    private int rating;
    private String review;
    private RentMethod rentMethod;
    private ReturnMethod rtrnMethod;
    private String movieID;

    @Override
    public boolean contains(String k) {
        return( dvd.getSerialNO().equalsIgnoreCase(k)); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String INFO() {
        return "RentDate is:"+ this.getRentDate()+ "Rutrn Date is:"+this.getReturnDate(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public enum Status {
        RENTED, NOTRENTED
    }
    public enum RentMethod{
        BYMAIL, GOTOSHOP
    }
    public enum ReturnMethod{
        DROPPING, SHIPPING
    }
    
    public Rental(String rentID, Calendar rtDate, Calendar rtrnDate, DVD dvd, 
                    Customer cust, RentMethod rentMethod, ReturnMethod rtrnMethod, String movID)
    {
        this.rentID = rentID;
        this.rentDate= rtDate;
        this.returnDate= rtrnDate;
        this.status=Status.RENTED;
        this.dvd=dvd;
        this.customer=cust;
        this.rentMethod=rentMethod;
        this.rtrnMethod=rtrnMethod;
        this.movieID=movID;
        dvd.setPosition(DVD.Position.RENTED);
        
        //Leave rating and review unsubstantiated, as they will be set when returning the rental.
    }
    
    //Specifically for NO_RENTAL, do not use otherwise.
    public Rental(String rentID)
    {
        this.rentID = rentID;
    }
    
    public String getRentDateString(){
      SimpleDateFormat formatter= new SimpleDateFormat("M-d-yyyy");
      String rentDateString= formatter.format(this.rentDate.getTime());// to change from calendar to date.
        
      return rentDateString; 
    }
    
    public String getReturnDateString(){
        SimpleDateFormat formatter= new SimpleDateFormat("M-d-yyyy");
        String returnDateString= formatter.format(this.returnDate.getTime());// to change from calendar to date.
        
        return returnDateString;
    }
    
    public Calendar getRentDate(){
        return this.rentDate;
    }
    
    public Calendar getReturnDate(){
        return this.returnDate;
    }
    
    public void setReturnDate(Calendar newRetDate){
        this.returnDate=newRetDate;
    }
    
    public String getRentalID(){
        return this.rentID;
    }
    
    public String getCustomer(){
        return customer.getName();
    }
    
    public String getCust(){
        return customer.INFO();
    }
    
    public String getDVD(){
        return dvd.getDVDInfo();
    }
    
    public String getMovieID(){
        return this.movieID;
    }
    
    public int getRating(){
        return this.rating;
    }
    
    public String getReview(){
        return this.review;
    }
    
    public void setRating(int rating){
        this.rating = rating;
    }
    
    public void setReview(String review){
        this.review = review;
    }
    
}
