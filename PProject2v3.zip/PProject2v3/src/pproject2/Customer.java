/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pproject2;

/**
 *
 * @author Mohamed, Adam
 */
public class Customer implements Searchable {
    
    private String email;
    private String address;
    private String phone;
    private String password;
    private String name;
    
    public Customer(String email, String address, String phone, String pass, String name){
        this.email=email;
        this.address= address;
        this.phone = phone;
        this.password=pass;
        this.name=name;
    }
    
    public Customer(String email){
        this.email=email;
    }
    
    public String getName(){
        return this.name;
    }
    public String getEmail(){
        return this.email;
    }
    public String getAddress(){
        return this.address;
    }
    public String getPhone(){
        return this.phone;
    }
    
    public void setName(String name){
        this.name=name;
    }
    public void setEmail(String email){
        this.email=email;
    }
    public void setPassword(String pass){
        this.password = pass;
    }

    @Override
    public boolean contains(String k) {
        return(this.getEmail().equalsIgnoreCase(k)); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String INFO() {
        return "Customer Name: "+ this.getName()+ "Customer E-mail is: "+ this.getEmail(); //To change body of generated methods, choose Tools | Templates.
    }
    

}
    

