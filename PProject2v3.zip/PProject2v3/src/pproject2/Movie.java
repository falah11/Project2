/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pproject2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import static java.util.Spliterators.iterator;
import pproject2.Actor.Gender;
import pproject2.DVD.Position;

/**
 *
 * @author Mohamed, Adam
 */
public class Movie implements Searchable {
    
    private String ID;
    private Rating rating;
    private String genre;
    private int year;
    private String name;
    private Language language;
    private DVD dvd;
    private Actor actor;
    private Keyword keywd;

    private HashMap<String,Actor> actors = new HashMap<String,Actor>();// list of actors in Movie
    private HashMap<String,DVD> dvds= new HashMap<String,DVD>();// list of dvd for each Movie
    private HashMap<String,Keyword> keywds= new HashMap<String,Keyword>();// list of keyword for a Movie
    
    public static final Keyword NO_KEY = new Keyword("nothing");
    public static final Actor NO_ACTOR = new Actor("nothing", "nothing", Actor.Gender.M);
    public static final DVD NO_DVD = new DVD("nothing");
   
    @Override
    public boolean contains(String k) {
       return(getID().equalsIgnoreCase(k));
    }
    
    @Override
    public String INFO() {
        boolean available = this.checkAvailability();
        return "Movie Name: " + this.name + 
                "\nMovie ID: " + this.ID +
                "\nMovie Rating: "+this.rating +
                "\nAvailable: " + Boolean.toString(available);
    }
    
    public enum Language{
        English, French, Spanish
    }
    public enum Rating{
        G, PG, PG_13, R
    }
    
    public Movie(String id){
        this.ID=id;
    }
    public Movie(String id, Rating rate, String gen, int yr, String name, Language lang, String dvdSN, Actor act, String key){
        this.ID=id; 
        this.rating=rate;
        this.genre= gen;
        this.year=yr;
        this.name=name;
        this.language=lang;
        this.addDVD(dvdSN);
        this.addActor(act);
        this.addKeyword(key);
    }
    
    public String getID(){
        return this.ID;
    }
    public String getName(){
        return this.name;
    }
    public Rating getRating(){
        return this.rating;
    }
    public String getGenre(){
        return this.genre;
    }
    public int getYear(){
        return this.year;
    }
    public Language getLanguage(){
        return this.language;
    }
    
    /*************
     * DVD methods
     *************/
    
    public void addDVD(String SN){
        DVD d = new DVD(SN);
        dvds.put(SN, d);
    }
    
    public void removeDVD(String SN){
        for(Entry<String,DVD> entry:dvds.entrySet()){
            if(entry.getKey().equalsIgnoreCase(SN)){
                dvds.remove(SN);
            }
        }
    }
    
    /*  Use: have an if statement checking that the returned dvd isn't null after
        using this method. */
    public DVD findDVD(String SN){
        for(Entry<String,DVD> entry: dvds.entrySet()){
            if(entry.getKey().contains(SN)){
                return entry.getValue();
            }
        }
        return NO_DVD;
    }
    
    public void listAvailableDVDs(){
        for(Entry<String,DVD> entry: dvds.entrySet()){
            DVD temp = entry.getValue();
            if(temp.getPos() == Position.NOTRENTED && !temp.isLost()){
                System.out.println(temp.getSerialNO());
            }
        }
    }
    
    public int numDVDs(){
        return dvds.size();
    }
    
    //  If at least one DVD is unrented and not lost, the movie is available.
    public boolean checkAvailability(){
        for(Entry<String,DVD> entry: dvds.entrySet()){
            DVD temp = entry.getValue();
            if(temp.getPos() == Position.NOTRENTED && !temp.isLost()){
                return true;
            }
        }
        return false;
    }
    
    
    /***************
     * Actor methods 
     ***************/
    
    public void addActor(Actor act){
        actors.put(ID, act);
    }
    
    /*  Use: have an if statement checking that the returned actor isn't null
        after using this method. */
    public Actor findActor(String ID){
        for(Entry<String,Actor> entry: actors.entrySet()){
            if(entry.getKey().contains(ID)){
              return entry.getValue();
            }
        }
        return NO_ACTOR;
    }
    
    /*****************
     * Keyword methods
     *****************/
    public void addKeyword(String k){
        Keyword kwd= new Keyword(k);
        keywds.put(k, kwd);
    }

    /*  Use: have an if statement checking that the returned keyword isn't null 
        after using this method. */
    public Keyword findKeyword(String k){
        for(Entry<String,Keyword> entry:keywds.entrySet() ){
            if(entry.getKey().contains(k)){
                return entry.getValue();
            }
        }
        return NO_KEY;
    }
    
}

    
    
 





    

