/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pproject2;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Mohamed
 */
public class DVD {
    
    private String serialNO;
    private boolean lost;
    private Position position;
    
    public enum Position{
     RENTED, NOTRENTED   
    }
    
    public DVD(String SN){
        this.serialNO= SN;
        this.lost=false;
        this.position= Position.NOTRENTED;
    }
    
    public String getSerialNO(){
        return serialNO;   
    }
    
    public boolean isLost(){
        return lost;
    }
    
    public void setLost(boolean lost){
        this.lost=lost;
    }
    
    public Position getPos(){
        return this.position;
    }
    
    public void setPosition(Position pos){
        this.position=pos;
    }
    
    public String getDVDInfo(){
        return "DVD serialNO: " + this.serialNO + "Lost: "+ this.lost + "Status: "+ this.position;
    }
    
}


    

